package dao;

// Uncomment for use

// import org.junit.jupiter.api.*;
// import static org.junit.jupiter.api.Assertions.*;

public class BookDAOJSONImplTest {

	// @Test
	// myTestMethod(){
	//    assertEquals(1,1);
	// }
}
