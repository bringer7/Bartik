The basic BookStore application:

- only servlet + JSPs
- not Maven-enabled
- a Maven-friendly structure for the source folders, still: src/main/java and src/main/test

The project can be converted to Maven, if needed.
